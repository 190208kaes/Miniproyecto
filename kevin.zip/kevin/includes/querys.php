<?php
include 'conecta.php'; // Asegúrate de que la ruta sea correcta

session_start(); // Inicia la sesión para almacenar datos del usuario si el login es exitoso

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Consulta para verificar el usuario en la base de datos
    $query = "SELECT * FROM usuario WHERE username = ?";
    $stmt = $Connect->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Verifica la contraseña
        if (password_verify($password, $user['password'])) {
            // Login exitoso, almacena los datos del usuario en la sesión
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            
            // Redirige a una página de bienvenida o panel de usuario
            header("Location: ../welcome.php");
            exit();
        } else {
            echo "Contraseña incorrecta.";
        }
    } else {
        echo "El usuario no existe.";
    }

    $stmt->close();
}
$Connect->close();
?>
