<?php
include 'includes/conecta.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    
    // Verificar que el usuario no exista
    $checkUserQuery = "SELECT * FROM usuario WHERE username = ?";
    $stmt = $Connect->prepare($checkUserQuery);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        echo "El usuario ya existe.";
    } else {
        // Insertar el nuevo usuario
        $insertUserQuery = "INSERT INTO usuario (username, password, nombre, apellido, numero_compras) VALUES (?, ?, ?, ?, 0)";
        $stmt = $Connect->prepare($insertUserQuery);
        $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hashear la contraseña
        $stmt->bind_param("ssss", $username, $hashed_password, $nombre, $apellido);
        
        if ($stmt->execute()) {
            echo "Registro exitoso.";
        } else {
            echo "Error al registrar el usuario.";
        }
    }
    $stmt->close();
    $Connect->close();
}
?>
