<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <style>
        .register-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f8f9fa;
        }
        .register-card {
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            overflow: hidden;
        }
        .image-side {
            background-image: url('ruta/a/tu/imagen.jpg');
            background-size: cover;
            background-position: center;
        }
        .form-side {
            padding: 2rem;
            background-color: #ffffff;
        }
    </style>
</head>
<body>
    <div class="container register-container">
        <div class="row w-75">
            <div class="col-lg-6 image-side d-none d-lg-block"></div>
            <div class="col-lg-6 col-12 form-side">
                <div class="text-center mb-4">
                    <h2>Create an Account</h2>
                </div>
                <form action="includes/registrar.php" method="POST">
    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" placeholder="Enter Username" required>
    </div>
    <div class="mb-3">
        <label for="nombre" class="form-label">Nombre</label>
        <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Enter Name" required>
    </div>
    <div class="mb-3">
        <label for="apellido" class="form-label">Apellido</label>
        <input type="text" class="form-control" id="apellido" name="apellido" placeholder="Enter Last Name" required>
    </div>
    <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" placeholder="Enter Password" required>
    </div>
    <div class="mb-3">
        <label for="confirm-password" class="form-label">Confirm Password</label>
        <input type="password" class="form-control" id="confirm-password" placeholder="Confirm Password" required>
    </div>
    <button type="submit" class="btn btn-dark w-100">Register</button>
</form>

                <div class="text-center mt-4">
                    <p>Already have an account? <a href="#" class="text-decoration-none">Sign In</a></p>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.querySelector('form').addEventListener('submit', function(e) {
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirm-password').value;
        if (password !== confirmPassword) {
            e.preventDefault();
            alert("Las contraseñas no coinciden.");
        }
    });
</script>


    <script src="librerias/bootstrap.bundle.min.js"></script>
</body>
</html>